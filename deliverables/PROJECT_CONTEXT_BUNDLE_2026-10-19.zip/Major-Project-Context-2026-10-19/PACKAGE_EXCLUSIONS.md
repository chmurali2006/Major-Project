# Package exclusions and inventory boundary

Snapshot: 2026-10-19 UTC. This is a curated project-context/source package, not a byte-for-byte repository or data/model release.

Included: source code, tests, protocols, markdown/text documentation, reference/plan files, sanitized notebook source (all cell outputs/execution counts/attachments stripped), CSV/JSON/log evidence and analysis tables, plus the refreshed overview DOCX and presentation draft PPTX.

Excluded by design:
- `.git` history, virtual environments, dependency caches, build outputs and temporary files.
- `google_drive/` contents (including the 40 MB T1 result ZIP and source metadata files). The T1 report/tables are included; visual case panels and any raw/user-provided archive are not redistributed.
- Raw medical-image pixels, image/media files, patient/source metadata spreadsheets, and notebooks' rendered outputs/attachments.
- Original mid-review/poster PDFs are not redistributed: embedded visual content has not been screened for medical pixels or permissions; a text-only transition record preserves reported claims and source links.
- Model weights/checkpoints and other binary inference artifacts; opaque NumPy/NPZ maps; all ZIP/TAR/RAR archives (contents not fully screened for source images or licensing).
- Full-text papers/PDFs and vector/raster figures. Bibliographic references/textual review notes remain where licensed/appropriate.
- Private keys, credentials, databases and obvious secret-named files.

Included path count: 456
The adjacent `PACKAGE_MANIFEST.csv` lists each included payload path, its post-sanitization byte count and SHA-256. The manifest does not hash itself or the final ZIP (which would be recursive); the final ZIP hash is recorded in the outer manifest file.

All exclusions are content/scope safeguards, not statements that omitted material does not exist. Obtain source/dataset/upstream licenses and owner approval before any redistribution.
